package com.project.trip_planner_safe.model;

public enum EventType {
    Concert, Muzeu, Dans, FoodTasting, WineTasting
}
