package com.proiect.trip_planner.controller;

public class TripController {
}
