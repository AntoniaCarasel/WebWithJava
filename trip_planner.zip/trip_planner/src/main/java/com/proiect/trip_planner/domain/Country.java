package com.proiect.trip_planner.domain;

public enum Country {
    USA, Romania, UK, Lithuania, Germany, Spain, Italy, Estonia, Netherlands, Latvia, Japan, France
}
