package com.proiect.trip_planner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TripPlannerApplicationTests {

    @Test
    void contextLoads() {
    }

}
